import solstice_extraButton
import solstice_fkButton
import solstice_ikButton
import solstice_flipButton
import solstice_ikfkSwitchButton
import solstice_keyButton
import solstice_mirrorButton
import solstice_flipButton
import solstice_pinButton
import solstice_moduleButton

def _reload():
    reload(solstice_extraButton)
    reload(solstice_fkButton)
    reload(solstice_ikButton)
    reload(solstice_flipButton)
    reload(solstice_ikfkSwitchButton)
    reload(solstice_keyButton)
    reload(solstice_mirrorButton)
    reload(solstice_flipButton)
    reload(solstice_pinButton)
    reload(solstice_moduleButton)