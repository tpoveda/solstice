# import sys
# sys.path.append('S:\solstice\solstice_tools')
# import solstice_picker as picker
# reload(picker)
# picker._reload()
# picker.summerPicker.solstice_summerPicker.initPicker(fullWindow=True)

# import maya.cmds as cmds
# sel = cmds.ls(sl=True)
# for obj in sel:
#     cmds.setAttr(obj+'.hiddenInOutliner', True)

# sel = cmds.ls(sl=True)
# for obj in sel:
#     cmds.setAttr(obj+'.overrideEnabled', True)
#     cmds.setAttr(obj+'.overrideVisibility', False)


